%% Load data set

[union_miRNA,L_in_ml,D_in_md,new_ml,new_md,new_ld,new_ml_association,...
    new_md_association,new_ld_association]=get_new_association;
new_lm_association = new_ml_association';
DATA=[];
a =0.52;
%% Retain the original correlation matrix and transpose
interaction = new_ld_association;
save interaction interaction;
[m1 ,disSim] = cosSim( new_md_association );
[lncSim1 ,m2] = cosSim( new_lm_association );
disSim1  = JaccardSim( new_md_association' );
lncSim  = JaccardSim( new_lm_association );
disSim2  = combineSim(disSim,disSim1);
lncSim2  = combineSim(lncSim1,lncSim);
ldwight =LDweight(new_lm_association,new_md_association);
%% Calculated scoring matrix
matPredict=LDAPWMPS(lncSim2,disSim2,ldwight,a);
%% result
[NCP_rank,NCP_rank_known] =Rank_miRNAs( matPredict, new_ld_association, L_in_ml, D_in_md);

%% Leave a cross-validation
index_1 = find(1 == interaction);
auc=zeros(1,100);
pp = length(index_1);
   for i = 1 : 100
    i
    indices = crossvalind('Kfold', pp, 5); %Randomly divide the data sample into 5 parts
    for j = 1:5  %Cycle 5 times, take the i-th part as the test sample and the other two parts as the training samples
       
        index_2 = find(j == indices);
        load interaction;
        interaction(index_1(index_2)) = 0; 
        [result]= LDAPWMPS(lncSim2,disSim2,ldwight,a);
        matPredict(index_1(index_2)) = result(index_1(index_2)); 
    end
    pre_label_score =matPredict(:);
    save pre_label_score_LDAPWMPS pre_label_score;
    load interaction;
    label_y = interaction(:);
    auc(i) = roc_1(pre_label_score,label_y);

   end
   auc_avg = mean(auc);
   std(auc);