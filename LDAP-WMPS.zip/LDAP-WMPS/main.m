%% Load data set

[union_miRNA,L_in_ml,D_in_md,new_ml,new_md,new_ld,new_ml_association,...
    new_md_association,new_ld_association]=get_new_association;
new_lm_association = new_ml_association';
DATA=[];
for a =0.52
%% Retain the original correlation matrix and transpose
interaction = new_ld_association;
save interaction interaction;
[m1 ,disSim] = cosSim( new_md_association );
[lncSim1 ,m2] = cosSim( new_lm_association );
disSim1  = JaccardSim( new_md_association' );
lncSim  = JaccardSim( new_lm_association );
disSim2  = combineSim(disSim,disSim1);
lncSim2  = combineSim(lncSim1,lncSim);
ldwight =LDweight(new_lm_association,new_md_association);
%% Calculated scoring matrix
matPredict=LDAPWMPS(lncSim2,disSim2,ldwight,a);
%% result
[NCP_rank,NCP_rank_known] =Rank_miRNAs( matPredict, new_ld_association, L_in_ml, D_in_md);

%% Leave a cross-validation
index_1 = find(1 == interaction);

for i = 1:length(index_1)
        i
        load interaction;
        interaction(index_1(i))=0;
        [result]= LDAPWMPS(lncSim2,disSim2,ldwight,a);
        matPredict(index_1(i)) = result(index_1(i));  
end
    pre_label_score =matPredict(:);
    save pre_label_score_LDAPWMPS pre_label_score;
    load interaction;
    label_y = interaction(:);
    auc = roc_1(pre_label_score,label_y);
    DATA(end+1)= auc;
    save DATA DATA
end